﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Akil_Alsharafi_HW1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            add_btn.Enabled = sub_btn.Enabled = div_btn.Enabled = mult_btn.Enabled = clear_btn.Enabled = false;
        }

        private void input_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox textbox = sender as TextBox;
            bool is_first = (textbox.Text.Trim() == "");

            if (!(e.KeyChar >= '0' && e.KeyChar <= '9'))
            {
                if (e.KeyChar == '-' && is_first) { }
                else if (e.KeyChar == '.' && !is_first) { }
                else if (e.KeyChar == '\b') { }
                else
                {
                    e.Handled = true;
                }
            }
        }
        private void input_KeyUp(object sender, KeyEventArgs e)
        {
            add_btn.Enabled = sub_btn.Enabled = div_btn.Enabled = mult_btn.Enabled = clear_btn.Enabled = !(fnum_textBox.Text == "" || snum_textBox.Text == "");
        }
        private bool input_check()
        {
            if (fnum_textBox.Text.Trim() == "")
            {
                MessageBox.Show("You Must Input the First Number .");
                fnum_textBox.Focus();
                return false;
            }
            else if (snum_textBox.Text.Trim() == "")
            {
                MessageBox.Show("You Must Input the Second Number .");
                snum_textBox.Focus();
                return false;
            }
            return true;
        }


        private void clear_btn_Click(object sender, EventArgs e)
        {
            fnum_textBox.Text = snum_textBox.Text = res_textBox.Text = "";
        }

        private void exit_btn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void op_btn_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;     
            if (input_check())
            {
                double fnum = Convert.ToDouble(fnum_textBox.Text.Trim());
                double snum = Convert.ToDouble(snum_textBox.Text.Trim();
                op_label.Text = btn.Text;
                if (btn.Text == "+")
                {
                    res_textBox.Text = (fnum + snum).ToString();
                }
                else if (btn.Text == "-")
                {
                    res_textBox.Text = (fnum - snum).ToString();
                }
                else if (btn.Text == "*")
                {
                    res_textBox.Text = (fnum * snum).ToString();
                }
                else if (btn.Text == "/")
                {
                    if (snum != 0)
                    {
                        res_textBox.Text = (fnum / snum).ToString();
                    }
                    else
                    {
                        MessageBox.Show("Second Can Not Be 0 .");
                        snum_textBox.Clear();
                        snum_textBox.Focus();
                    }
                }
            }
        }



    }
}

